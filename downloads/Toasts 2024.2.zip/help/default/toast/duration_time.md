The toast will be displayed for this amount of milliseconds (1000ms = 1s).
Once the time is reached, the toast will be removed.